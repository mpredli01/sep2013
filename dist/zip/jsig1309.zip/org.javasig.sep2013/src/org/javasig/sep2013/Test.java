package org.javasig.sep2013;

public class Test {
    public static void main(String[] args) {
        System.out.println("Testing, 1, 2, 3...");
        }
    }
